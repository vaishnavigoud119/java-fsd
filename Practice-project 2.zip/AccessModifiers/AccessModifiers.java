package AccessModifiers;

	import java.util.Scanner;
	public class AccessModifiers {
	 private int privateVar;
	 protected int protectedVar;
	 public int publicVar;
	 public AccessModifiers(int privateVar, int protectedVar, int publicVar) {
	 this.privateVar = privateVar;
	 this.protectedVar = protectedVar;
	 this.publicVar = publicVar;
	 }
	 private void privateMethod() {
	 System.out.println("This is a private method.");
	 }
	 protected void protectedMethod() {
	 System.out.println("This is a protected method.");
	 }
	 public void publicMethod() {
	 System.out.println("This is a public method.");
	 }
	 public static void main(String[] args) {
	 Scanner input = new Scanner(System.in);
	 System.out.print("Enter a value for privateVar: ");
	 int privateVar = input.nextInt();
	 System.out.print("Enter a value for protectedVar: ");
	 int protectedVar = input.nextInt();
	 System.out.print("Enter a value for publicVar: ");
	 int publicVar = input.nextInt();
	 AccessModifiers obj = new AccessModifiers(privateVar, protectedVar, 
	publicVar);
	 System.out.println("privateVar: " + obj.privateVar); // This will not compile since privateVar is private
	 System.out.println("protectedVar: " + obj.protectedVar);
	 System.out.println("publicVar: " + obj.publicVar);
	 // obj.privateMethod(); // This will not compile since privateMethod is private
	 obj.protectedMethod();
	 obj.publicMethod();
	 
	 }
	}


