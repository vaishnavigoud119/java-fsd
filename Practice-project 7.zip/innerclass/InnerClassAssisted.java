package innerclass;

public class InnerClassAssisted {
	    private String welcomeMsg = "welcome to java,let us start java inner classes";
	    
	    public void start() {
	        InnerClass innerObj = new InnerClass();
	        innerObj.displayMsg();
	        
	        AnonymousInnerClass anonInnerObj = new AnonymousInnerClass() {
	            public void displayMsg() {
	                System.out.println(" anonymous inner class.");
	            }
	        };
	        anonInnerObj.displayMsg();
	    }
	    
	    class InnerClass {
	        public void displayMsg() {
	            System.out.println(welcomeMsg);
	            System.out.println(" inner classes.");
	        }
	    }
	    
	    abstract class AnonymousInnerClass {
	        public abstract void displayMsg();
	    }
	    
	    public static void main(String[] args) {
	    	InnerClassAssisted example = new InnerClassAssisted();
	        example.start();
	    }
	}

