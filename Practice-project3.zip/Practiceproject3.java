package assignment;

public class Practiceproject3 {
	    public static int exponentialSearch(int[] array, int target) {
	        if (array[0] == target) {
	            return 0;  // Return 0 if the target is found at the beginning
	        }

	        int n = array.length;
	        int i = 1;
	        while (i < n && array[i] <= target) {
	            i *= 2;  // Double the value of i for each iteration
	        }

	        return binarySearch(array, target, i / 2, Math.min(i, n - 1));
	    }

	    public static int binarySearch(int[] array, int target, int left, int right) {
	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (array[mid] == target) {
	                return mid;  // Return the index where the target is found
	            } else if (array[mid] < target) {
	                left = mid + 1;  // Continue searching in the right half
	            } else {
	                right = mid - 1;  // Continue searching in the left half
	            }
	        }

	        return -1;  // Return -1 if the target is not found
	    }

	    public static void main(String[] args) {
	        int[] array = {1, 2, 3, 5, 8, 10};
	        int target = 8;

	        int index = exponentialSearch(array, target);

	        if (index != -1) {
	            System.out.println("Target found at index " + index);
	        } else {
	            System.out.println("Target not found");
	        }
	    }
	}
