package assignment;

public class Practiceproject6 {
	    public static void insertionSort(int[] array) {
	        int n = array.length;

	        for (int i = 1; i < n; i++) {
	            int key = array[i];
	            int j = i - 1;

	            while (j >= 0 && array[j] > key) {
	                array[j + 1] = array[j];
	                j--;
	            }

	            array[j + 1] = key;
	        }
	    }

	    public static void main(String[] args) {
	        int[] array = {64, 34, 25, 12, 22, 11, 90};

	        System.out.println("Array before sorting:");
	        printArray(array);

	        insertionSort(array);

	        System.out.println("Array after sorting:");
	        printArray(array);
	    }

	    public static void printArray(int[] array) {
	        for (int num : array) {
	            System.out.print(num + " ");
	        }
	        System.out.println();
	    }
	}
