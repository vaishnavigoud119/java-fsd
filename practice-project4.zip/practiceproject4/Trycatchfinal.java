package practiceproject4;

public class Trycatchfinal 
{
    public static void main(String args[]) 
    {
        try 
        {
            int i=10/0;
            System.out.println("1"); 
        }
        catch (Exception e) 
        {
            System.out.println(e); 
            System.out.println("2"); 
        }
        finally 
        {
            System.out.println("i am executed");
        }
        System.out.println("3"); 
    }
}
