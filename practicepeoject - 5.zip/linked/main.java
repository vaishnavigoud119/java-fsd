package linked;

public class main {
	    public static void main(String[] args) {
	        LinkedList linkedList = new LinkedList();

	        // Insert elements into the linked list
	        linkedList.insert(5);
	        linkedList.insert(10);
	        linkedList.insert(15);
	        linkedList.insert(20);

	        System.out.println("Original Linked List:");
	        linkedList.display();

	        int key = 10;
	        linkedList.delete(key);

	        System.out.println("Linked List after deleting first occurrence of " + key + ":");
	        linkedList.display();
	    }
	}
