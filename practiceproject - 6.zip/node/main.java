package node;
public class main {
	 public static void main(String[] args) {
	        CircularLinkedList circularLinkedList = new CircularLinkedList();

	        // Insert elements into the sorted circular linked list
	        circularLinkedList.insert(10);
	        circularLinkedList.insert(20);
	        circularLinkedList.insert(30);
	        circularLinkedList.insert(40);

	        System.out.println("Original Sorted Circular Linked List:");
	        circularLinkedList.display();

	        int newElement = 25;
	        circularLinkedList.insert(newElement);

	        System.out.println("Sorted Circular Linked List after inserting " + newElement + ":");
	        circularLinkedList.display();
	    }
}
