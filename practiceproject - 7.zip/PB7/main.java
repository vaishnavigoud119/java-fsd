package PB7;
	public class main {
	    public static void main(String[] args) {
	        DoublyLinkedList dllist = new DoublyLinkedList();
	        dllist.append(1);
	        dllist.append(2);
	        dllist.append(3);
	        dllist.append(4);
	        dllist.append(5);

	        System.out.println("Forward traversal:");
	        dllist.traverseForward();

	        System.out.println("Backward traversal:");
	        dllist.traverseBackward();
	    }
	}

